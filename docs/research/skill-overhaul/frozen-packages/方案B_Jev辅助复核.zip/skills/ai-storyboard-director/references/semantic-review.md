# Jev可选文字复核

保留与A相同的源材料、初稿、锁定要求和修订边界。Jev只核对提交的文字，不生成镜头、不直接看图片或视频，不自动改稿、采用创意候选或决定用户审美。

脚本仅用Python标准库。输入JSON包含source、locked_facts、deliverable、observed_evidence。source和deliverable至少含text；locked_facts最多12项，每项含id、text、severity（major/minor）、target（deliverable或观察id），可选question_type（choice/noul）及唯一原文excerpt。observed_evidence为实际观察的文字数组，每项含id、type:text、text，可为空；计划不是执行证据。

先运行本地检查：`python -B scripts/semantic_review.py --mode local --input INPUT.json`。只有当前材料允许外发、调用范围已获授权且当前进程安全注入TYPESAFE_API_KEY，才运行`python -B scripts/semantic_review.py --mode jev --allow-external --input INPUT.json`。不把密钥写入文档、输入JSON、命令行或回执。

一次批量请求，不自动重试。缺密钥、未允许外发或服务失败返回failed，不伪称B通过；review_required与candidate_repair只供主流程回读原文确认，修复后仅重查受影响要求。no_issue_detected仅表示本次文字未发现明确问题，不等于用户接受、媒体效果或可靠性保证。概率阈值是待校准分流策略，不是准确率。需要核实协议与模型时查官方https://docs.typesafe.ai/api及https://docs.typesafe.ai/models。
