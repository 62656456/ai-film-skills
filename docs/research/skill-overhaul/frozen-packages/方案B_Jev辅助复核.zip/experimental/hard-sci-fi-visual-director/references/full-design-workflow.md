# Full world and visual-system design workflow

Use for a complete original world, visual bible, new system or asset family, or a substantial redesign involving interdependent open decisions. The entrypoint routes bounded questions and local corrections directly to the affected knowledge; they do not run this full workflow by default.

Keep the complete professional method below. Execute only gates applicable to the source, medium and allowed changes. Internal cards support decisions; show only the requested deliverable. The standard multi-part report is for a requested full design package, not a default appendix to a single answer or image. Current user scope and locked decisions remain authoritative.

## Fixed method and variable design


### Fixed across projects

- one current authority source and explicit version;
- separation of `FACT`, necessary `DERIVATION`, reversible `PROPOSAL`, and approved `LOCKED` decisions;
- research for design-changing gaps before visual inference, with opened traceable sources rather than snippets or memory;
- verified fact, constrained extrapolation, and explicit hypothesis kept distinct;
- physical consequences for energy, heat, load, motion, medium, maintenance, biology, and failure where those systems matter;
- source mechanism may transfer; source appearance, franchise identity, signature composition, and palette may not;
- every important world claim ends in deliverable-visible evidence, and the requested medium's information capacity is checked before composition;
- interfaces serve a real declared agent/system task or test model and never rescue missing dramatic or physical blocking;
- weapon and defense design remains non-actionable;
- image generation requires an explicit user request; generation and internal pass never equal user approval.

### Derived for each script or project

- future degree and imagination amplitude;
- world rules, civilization, institutions, scarcity, daily life, and operating history;
- environment, geography, architecture, medium, weather, hazards, and routes;
- production route and practical/VFX split;
- style thesis, palette, contrast, lighting hierarchy, camera, lens, and information order;
- characters, bodies, machines, organisms, equipment families, interfaces, damage, and wear;
- whether the scene is active, quiet, ambiguous, relational, establishing, aftermath, or reference-only.

A derived choice becomes a project continuity rule only after the user approves it and its scope/version is recorded. Shot-level choices remain variable unless the approved bible locks them.

## Source authority and decision status

Use this order:

1. current explicit user instructions and corrections;
2. named current screenplay/version and selected beat;
3. approved project bible, locks, and anchor frames;
4. verified research constraints for an open gap;
5. reversible director proposals;
6. optional route vocabulary and examples.

Record `剧本权威卡`, `剧本—视觉转译卡`, and `视觉决策状态表` from the derivation reference. Never promote a generated image, internal score, or research result to project authority. Use `OPEN`, `PROVISIONAL`, `CANDIDATE`, `APPROVED`, `LOCKED`, and `REJECTED` precisely.

If research contradicts a script fact, expose the conflict and offer two labeled choices: revise the script, or declare a fictional axiom and propagate its costs. Do not silently repair the screenplay.

## Research and creative amplitude

Research sets the evidence floor, not the design ceiling. Preserve explicit source facts and user locks, formulate questions from open design gaps, then search and open the sources before choosing any new mechanism, future degree, system route, form, palette, or reference language.

For each design-changing research pass record query/date, opened source and section, source class/maturity, supported claim, transferable mechanism, visible trace, limitation/conflict/cost, evidence gap, and literal traits to discard. Search-result snippets and model recollection are not evidence.

When the source or user asks for high imagination, select an explicit amplitude after research:

- `I 现实增压`: verified systems reorganized into a new operation or social consequence;
- `II 世界规则变形`: one constrained speculative rule changes multiple visible systems;
- `III 文明/物理跃迁`: an explicit hypothesis reorganizes bodies, infrastructure, institutions, ecology, or time while paying visible costs.

High imagination does not require action, crisis, sacrifice, a technician, or a particular future date. For amplitude II–III or original flagship world design, explore enough distinct topology or behavior routes to escape the first familiar answer, combine a verified anchor with a non-adjacent mechanism when useful, and reject present-day substitution. Do not force a candidate count, expose options the user did not request, or merge routes into a compromise body. In single-author or design-repair mode, select one coherent route after internal comparison and show only that route. Routine shots inside an approved world may reuse locked research and do not need a new “second leap.”

## Function-specific visual contract

Choose one primary contract from the script beat. Declare a secondary contract only when the source genuinely combines functions and both can remain legible without one replacing the other:

- **Action/decision**: `actor or responsible system → action → physical target → changed state → script-supported consequence or cost`.
- **Discovery/information**: `observer → physical evidence → change in attention or understanding`, preserving intentional mystery.
- **Relationship/power**: `spatial control, access, distance, gesture, exchange, or blockage → response → relational/emotional shift`.
- **Establishing/atmosphere**: `location function → active world or causally active emptiness → latent route, condition, or pressure`.
- **Aftermath/transition**: `trace → implied cause → affected new state`, without revealing what the script withholds.
- **Isolated asset/reference**: `identity → function → scale → applicable interfaces or relationships → material/operating logic`, with no invented crisis or user.

The three-second no-text causal chain is a hard gate for action or decision beats that should read immediately. Other functions use their own evidence and information-order gate. UI text, captions, and lore may confirm but cannot be the only essential evidence.

## Direction workflow

1. **Identify one current source.** Name screenplay/project/version/scene/beat or label a user premise as provisional.
2. **Protect the story.** Record explicit facts, must-preserve causality and emotion, prohibited rewrites, necessary inferences, open gaps, and one material unknown.
3. **Diagnose the beat and medium capacity.** Lock dramatic function, character/system objective, obstacle, emotion curve, information order, spatial power, and the matching visual contract. Decide whether the requested still, sequence, animation, asset sheet, or interface study can actually carry the required temporal and causal information.
4. **Form research questions from gaps.** Do not search for a look before knowing what the script leaves open.
5. **Search before new design inference.** Open authoritative or primary technical sources and independent production/human-factors evidence where relevant; build the evidence card.
6. **Classify evidence.** Separate verified fact, constrained extrapolation, explicit hypothesis, and production lesson. Extract mechanisms and discard source appearance.
7. **Build the physical boundary.** Define only relevant gravity, medium, pressure, temperature, light, reference frame, motion, energy, heat, biology, failure, and uncertainty.
8. **Derive world and environment.** Use `script need → operation → constraint → design response → visible evidence → deliverable/viewer evidence`; avoid encyclopedia lore.
9. **Resolve open identity decisions.** Compare distinct mechanisms, environments, production routes, style theses, or topologies only where the source has not decided them. When the user asks for one design, do not manufacture a public option set. For a new combat-mecha identity, classify single/family/variant/independent-story scope, then lock one visual proposition, black silhouette, body rhythm, and two or three identity anchors before detailed systems or prompts. Plural independent requests require justified divergence rather than one body with new skins.
10. **Select a working route without inventing canon.** Mark it PROVISIONAL or CANDIDATE until user approval. Reuse APPROVED/LOCKED project decisions within their scope.
11. **Build the required spatial model.** For a scene, location, inhabited system, or related shots, resolve only the orientation, zones, adjacency, routes, flows, hazards, viewer access, production footprint, and extension/layer boundary the beat needs. For an explicitly isolated neutral asset, use only the scale, views, applicable interfaces/relationships, clearances, states, and family relations that define it instead of inventing geography.
12. **Block the selected visual contract.** Put its essential evidence in the composition before interface graphics, labels, or spectacle.
13. **Resolve systems and bodies at the correct stage.** Derive shape, materials, access, interfaces, support, power/heat, wear, biology, manufacturing, and operating history only where the scene needs them. For combat-mecha form work, do not begin detailed engineering until the silhouette and body-rhythm gate passes; mechanics must resolve the selected form rather than generate a generic industrial body.
14. **Choose production and camera from dramatic purpose.** Derive viewpoint, distance, lens, height, occlusion, focus, movement, and layer strategy from information reveal, spatial power, body relation, and deliverable—not from a cross-project lens default.
15. **Derive style and color.** Build a custom coherent style thesis or use route vocabulary diagnostically; derive palette and source hierarchy from story function, environment physics, material, information order, emotion, exposure, and approved continuity.
16. **Design interface only if required.** Map it to the responsible human/nonhuman/collective/autonomous or `no operator` model, authority/governance, real or declared system topology, perception/presentation, input/control when present, confirmation only when critical, feedback, applicable degraded mode, environment, and production method. In narrative/world frames use independent physical/world evidence; in isolated UI/HMI assets use the declared internal-redundancy contract.
17. **Lock continuity when triggered.** Freeze bible version and `continuity_in → intentional change → continuity_out`; do not let candidates rewrite it.
18. **Write the prompt.** Lead with the selected function contract and information order; include only deliverable-visible world evidence and relevant physical constraints.
19. **Audit the prompt.** Apply universal gates, then only the conditional gates triggered by the source and deliverable.
20. **Generate and inspect only when authorized.** A prompt pass means `结构就绪`; a file means `已生成`; visible audit may yield `内部通过` or `失败/修改`; only the user may mark `用户接受`.

## Universal hard gates

Do not output a final design-changing prompt until every applicable answer is yes:

1. Is one current authority source/version identified?
2. Are FACT, necessary DERIVATION, open gap, reversible PROPOSAL, approved LOCKED decisions, and prohibited rewrite separated?
3. Does the visual contract match the screenplay's dramatic function, emotion curve, information order, and spatial power?
4. Does every major world, environment, style, color, camera, asset, or interface choice trace to a script need, verified constraint, or approved project lock?
5. Did actual search and source opening occur after source analysis but before new design-changing inference, unless the task legitimately reuses a current approved evidence card or the user authorized an offline preliminary?
6. Are verified facts, extrapolations, hypotheses, production lessons, limitations, and evidence gaps distinct?
7. Are physical claims consistent with medium, gravity, energy, heat, load, motion, biology, human behavior, and failure consequences relevant to the scene?
8. Does every important world claim leave visible spatial, material, behavioral, institutional, or environmental evidence at the selected shot scale?
9. Is there a plausible camera/viewer position and coherent perspective appropriate to the production route?
10. Are world, environment, production route, style, color, and camera derived rather than inherited as one house-style bundle?
11. Does important light/color have a causal source, medium/material interaction, exposure behavior, story role, and continuity state? Multiple sources are allowed when the location and beat justify their hierarchy.
12. Do form, materials, interfaces, wear, access, and detail distribution follow function and history rather than generic greeble or dirty-future decoration?
13. Is the dominant design original and stripped of recognizable franchise silhouettes, palettes, interface layouts, symbols, and signature compositions?
14. Are all unapproved identity choices still labeled PROVISIONAL or CANDIDATE rather than canon?
15. Does the prompt preserve the source's intended knowledge, ambiguity, causality, relationship, and emotional outcome?
16. Is the result within the non-actionable weapons boundary and other safety limits?
17. Can the requested deliverable carry the required information order without explanatory text? For a single still, is the decisive threshold readable through a compatible before-state trace, current action/state, and emerging result; if not, is the unavoidable ambiguity reported and a two-frame or motion alternative offered instead of adding UI clutter?

## Conditional hard gates

- **Action/decision**: without title, captions, or UI text, are action, target, changed state, and script-supported consequence readable at the intended viewing time?
- **Discovery/information**: are observer, evidence, attention/understanding shift, and intended unknown readable without inventing a crisis?
- **Relationship/power**: do blocking, access, gesture, distance, or object exchange carry the relational change rather than a substituted technical event?
- **Establishing/atmosphere**: does the place reveal function, active life or causal emptiness, and a latent route/condition without an invented protagonist or failure?
- **Aftermath/transition**: do trace and new state imply the correct cause while preserving withheld information?
- **Asset/reference**: are identity, function, scale, applicable interfaces/relationships, and material logic clear without an invented story beat?
- **High-imagination amplitude II–III**: after removing names, UI, grade, and setting labels, does a world-specific relationship remain that fails present-day substitution and changes at least three relevant visible axes?
- **Live action/hybrid**: do the source-required photographed subject/environment/performance/contact evidence, production layers, extension, optics, lighting, and exposure form one reality without shrinking the idea to a buildable foreground or inventing an actor/prop?
- **Interface in a narrative/world frame**: is it necessary, task-specific, system-matched, coupled to the source-derived body/governance and world, readable by large state/topology, independently confirmed where critical, and free of generic black-box/percentage/retro/hologram decoration?
- **Isolated UI/HMI asset or interaction reference**: does the declared task, system model, user/agent modality, state transition, confirmation/fallback, carrier, and large-scale information hierarchy remain testable without inventing an external story scene? Redundant cues may exist inside the interface prototype, but decorative data may not substitute for a system model.
- **Populated busy scene**: do background groups have purposeful routes and continuing action? Empty or intimate scenes need no crowd.
- **Nonhuman organism/ecology**: are story status and science status separate; do habitat, energy/ecological role, organization, sensing, movement/growth, regional material behavior, scale/activity, and environment response agree; and are familiar-animal, engineered-shell, decorative-glow, and franchise defaults removed?
- **Mecha/megafauna**: do support, mass/buoyancy, motion limits, power/heat or biology, environment response, operating/automation/body relation when applicable, and scale proofs agree?
- **Humanoid combat mecha**: with names, marks, palette, removable weapons, setting, and effects hidden, is there a memorable small-scale silhouette, deliberate head/chest/waist/pelvis/limb rhythm, and two or three cooperating identity anchors before engineering detail; and do combat responsibility, humanoid load chain, threat/protection geometry, survivability, sensing/governance, actuation, support, and current state strengthen that distinct non-franchise body rather than turn it into an ape, construction rig, or generic armored humanoid?
- **Human–mecha scale**: does the selected human/machine ratio follow story, combat condition, operator relation, vulnerability, danger radius, access, and intended emotion; is it proven by connected intermediate anchors and reflected in camera distance/height/crop rather than asserted with a tiny person; and was it re-evaluated without forcing change when continuity justifies the same scale?
- **Combat-mecha identity visibility**: when the deliverable is meant to validate a new design, are the contract's minimum head/sensor, body-plan, and second-silhouette/load anchors visible at normal viewing size despite cinematic crop and occlusion; if one frame cannot carry both story and identity, was a separate diagnostic view requested rather than hiding the design?
- **Independent combat-mecha set**: before prompts or images, does the divergence matrix prove different story responsibility, body/second-silhouette logic, environment/light relation, and camera purpose rather than one shell with changed equipment, damage, color, or background; and does the sample-leak test reject any unjustified reuse of an earlier example set?
- **Ordinary future equipment**: do family identity, function, applicable interfaces/relationships, energy/data only when used, body/environment relation when embodied, and only the protection, service/lifecycle, logistics, and condition the brief requires form a coherent non-template system without inventing combat or industrial electronics?
- **Weapon/defense/rescue-hazard system**: do applicable echelon, authorization, effect, power, heat/reaction, logistics, service, safe arc/protection, localized condition, and role/body/environment relation form an original non-actionable family at the requested state?
- **Continuity**: does each related frame preserve the approved bible, axes, geography, light/color state, material history, equipment identity, and causal state transition?

## Camera, production, people, and interface rules

- A physical camera anchor is mandatory for photographed routes; no focal length or distance is preferred across all scripts. Intimate proximity, remote observation, extreme width, telephoto compression, fixed surveillance, macro detail, or an impossible-human-but-valid sensor viewpoint may each be correct when the beat and production route justify it.
- For photographed live-action/hybrid routes, a practical or photographable contact/performance/environment anchor is a grounding layer, not a ceiling; extend scale or altered geography through the selected miniature, volume, in-camera, animation, or invisible-VFX method. Illustration, animation, sensor, UI, and asset-reference routes use their own coherent layer/projection system and require no practical foreground.
- Do not add an adult technician, repair task, handwheel, warning screen, crowd, damage, or sacrifice unless the source or derived operation requires it.
- In inhabited busy scenes, background activity must have direction, purpose, route, contact, and continuity. In quiet, intimate, empty, or reference scenes, protect stillness and do not populate for scale.
- Interface form comes from task, body, environment, authority, failure safety, maintenance, and real system topology. Physical does not mean retro. Precise typography belongs in post when image generation cannot guarantee it.
- Avoid named living-artist or filmmaker imitation. Translate references into observable camera, production, material, light, rhythm, and narrative relations.
- Avoid automatic rain night, teal-orange, gray equipment maintenance, centered hero machines, blue LED seams, full-frame fog, decorative holograms, universal grime, random text, and equal-density detail.
- Allow strong color, unusual light, silence, ambiguity, spectacle, or visual extremity when the screenplay and physical source pay for it. Restraint is not synonymous with realism.

## Standard output

Unless the user asks for another format, return:

0. `视觉命题与尺度/人机关系`: one first-read visual proposition; the subject's scale relation to people, environment, infrastructure, threat, or protected space; and why the body must organize this way. Later engineering must explain and strengthen this proposition rather than replace it with a checklist. Mark inapplicable fields `N/A` for people-free, noncombat, natural, abstract, or neutral-asset tasks; never invent a person, tactic, crisis, operator, or story event to fill the card.
1. `剧本事实与视觉空白`: authority card, dramatic analysis, selected function contract, forbidden rewrites, and open gaps.
2. `研究与视觉推导`: research questions, opened evidence, fact/extrapolation/hypothesis split, limitations, no-copy traits, and major derivation chains.
3. `候选路线与决策状态`: genuinely different proposals only for open identity decisions, plus rejected routes and selection reason; otherwise state the reused approved route without manufacturing alternatives. Record OPEN/PROVISIONAL/CANDIDATE/APPROVED/LOCKED status.
4. `视觉圣经或资产圣经`: include only the world, environment, production route, spatial model, systems/bodies, style thesis, color logic, viewpoint/camera, interfaces, family grammar, and continuity applicable to the requested deliverable.
5. `视觉导演方案`: concise explanation of what the audience sees, knows, and feels, and why the frame expresses the source beat.
6. `完整提示词`: one copy-ready fenced `text` block.
7. `负面约束`: one separate fenced `text` block containing only likely failures for this scene.
8. `自检与状态`: applicable gates, unknowns, image status, and user-approval status.

When a combat-mecha identity is new, rejected, or under form repair, first return only the stage-appropriate package from `combat-mecha-form-direction.md`: `视觉命题`, `轮廓与身体节奏`, two or three identity anchors, applicable human-scale relation, the engineering resolution that preserves the form, and current status/next acceptance point. Do not automatically output a research encyclopedia, multi-route table, full system card, scene card, prompt, or image. After identity approval—or when the user's latest instruction explicitly requests direct generation—add only the applicable system, source-form deletion, scene/light, prompt, negative, and continuity fields. Add `多机甲差异矩阵` only for genuinely plural family or independent-story requests. Record a stable `contract_id`; the brand-free image prompt must be derived after a design contract exists, never written first and justified retroactively.

For `只要提示词`, return only prompt and scene-specific negative constraints after performing the required analysis internally. For diagnosis, return `主失败 → 可见证据 → source/physics/camera/design cause → one correction`; add a revised prompt only when the user asks to optimize/rewrite or the request clearly includes correction, and do not generate unless asked. For related multi-image work, add the versioned scene bible, shot-state cards, and story-order CONTACT-SHEET bridge without renumbering or replacing old assets.

## Prompt construction requirements

The complete prompt must:

- name ratio/deliverable and the camera or viewer relation required by the selected production route;
- begin with the selected function contract, information order, and dominant composition rather than an inventory of technology;
- for a single still, encode only temporally compatible evidence in one threshold moment; never combine mutually exclusive before/after states merely to make the whole plot fit;
- preserve every must-keep source fact and exclude prohibited rewrites;
- include only world, institution, history, and research claims that terminate in visible evidence;
- describe the environment's effect on body, motion, material, sound proxy, light, access, or behavior;
- specify relevant physical cause and consequence without forcing unrelated engineering exposition;
- derive form, material, interface, wear, and detail distribution from mission, environment, history, and approved project grammar;
- when a nonhuman organism or ecology is present, separate story truth from scientific evidence and state the habitat/energy boundary, selected organization, sensing/signaling, movement/growth, regional material behavior, environment response, withheld identity, and familiar Earth/franchise traits to delete;
- state production layers and optics only for the selected production route;
- translate style into observable narrative posture, camera relation, rhythm, material-information distribution, and contrast rather than route labels;
- translate color into source, medium/material, exposure, information/emotional role, state transition, and continuity rather than universal hues or area percentages;
- when UI is present, state the responsible human/nonhuman/collective/autonomous or `no operator` task/test model, sensed or declared system, topology, perception/presentation, input or governance, confirmation where critical, applicable feedback and degraded mode, carrier or signaling medium, production behavior, and post-text boundary; require independent world evidence only for narrative/world frames and internal redundant cues for isolated UI/HMI assets;
- for high-amplitude flagship design, state the explicit speculative rule, cost, source-form deletion, visible downstream changes, and the grounding/extension or layer relation appropriate to the selected production route; practical/VFX language applies only to live-action/hybrid routes;
- for continuity work, restate critical entering state and allowed change instead of saying `same as previous`;
- place labels such as `photorealistic`, `large-format`, or `cinematic` only after concrete observable decisions;
- end with short scene-specific exclusions that protect the concept without suppressing story-authorized wonder, color, silence, motion, or scale;
- never claim that prompt compliance, generation, or internal scoring equals user-approved quality.

Favor observable relationships over adjective stacks. Preserve the screenplay first; research its gaps; then design boldly within evidence, physics, production, and approved project continuity.
