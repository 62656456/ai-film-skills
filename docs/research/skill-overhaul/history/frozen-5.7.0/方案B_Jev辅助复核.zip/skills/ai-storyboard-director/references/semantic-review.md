# Jev可选文字复核

仅当前任务已选择Jev辅助复核时使用，保留与A版相同的导演核心与当前成品。图像、音频和视频必须由真实观察形成文字证据，Jev不会直接读取媒体。不要把计划当执行证据，不做全局电影感排名。

本包脚本只有Python标准库依赖。输入JSON为source、locked_facts、deliverable、observed_evidence四项；source和deliverable至少含text。locked_facts每项含id、text、severity（major/minor）、target（deliverable或观察id），可选question_type（choice/noul）与唯一原文excerpt。observed_evidence每项含id、type:text、text，可为空。

先运行本地检查：`python -B scripts/semantic_review.py --mode local --input INPUT.json`。在当前材料允许外发且当前进程安全注入TYPESAFE_API_KEY后，才运行`python -B scripts/semantic_review.py --mode jev --allow-external --input INPUT.json`。不把密钥写入文件、命令行或回执。

每次最多12项窄要求，一次批量请求；不自动重试。缺密钥、未授权外发或服务失败返回failed，不冒充A/B通过。review_required和candidate_repair都是需要主流程复核的信号；没有确定证据不能直接判错。修复保持未涉及内容，之后只重查受影响要求。

no_issue_detected只表示本次文字问题未发现明确缺陷，不代表中文语义可靠、真实媒体执行或用户接受。阈值是未校准的分流策略，不是准确率。官方协议与模型在需要时从https://docs.typesafe.ai/api、https://docs.typesafe.ai/models核验。本候选客户端已离线验证，真实Jev效果待凭证和实际样本验证。
